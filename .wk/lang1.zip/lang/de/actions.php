<?php

return [

	'back'     => 'Zurück',
	'cancel'   => 'Abbrechen',
	'delete'   => 'Löschen',
	'login'    => 'Anmelden',
	'logout'   => 'Abmelden',
	'profile'  => 'Konto',
	'settings' => 'Einstellungen',
	'new'      => 'Neu',
	'ok'       => 'OK',
	'register' => 'Registrieren',
	'save'     => 'Speichern',
	'search'   => 'Suchen',
	'admin'    => 'Administration',

];
