<?php

return [

	'success'         => 'Erfolg',
	'error'           => 'Fehler',
	
	'saved_success'   => 'Dokument erfolgreich gespeichert.',
	'saved_error'     => 'Fehler beim Speichern des Dokuments.',
	
	'deleted_success' => 'Dokument erfolgreich gelöscht.',
	'deleted_error'   => 'Fehler beim Löschen des Dokuments.',
	
	'yes' => 'Ja',
	'no'  => 'Nein',

];
