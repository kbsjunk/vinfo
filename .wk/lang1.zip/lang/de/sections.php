<?php

return [

	'account'      => 'Konto',
	'settings'     => 'Einstellungen',
	'admin'        => 'Konfiguration',
	'countries'    => 'Länder',
	'currencies'   => 'Währungen',
	'bottle_sizes' => 'Flaschengrößen',
	'users'        => 'Benutzer',
	'languages'    => 'Sprachen',

];
