<?php

return [

	'account'      => 'Account',
	'settings'     => 'Settings',
	'admin'        => 'Configuration',
	'countries'    => 'Countries',
	'currencies'   => 'Currencies',
	'bottle_sizes' => 'Bottle Sizes',
	'users'        => 'Users',
	'languages'    => 'Languages',
	'details'    => 'Details',
	'translations'    => 'Translations',

];
