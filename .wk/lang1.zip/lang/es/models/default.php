<?php

return [
	'attributes' => [
		'id'              => 'Clave',
		'id_help'         => 'La clave del registro.',
		'code'            => 'Código',
		'code_help'       => 'El código del registro.',
		'name'            => 'Nombre',
		'name_help'       => 'El nombre del país.',
		'created_at'      => 'Creado el',
		'created_at_help' => 'La fecha de creación.',
		'updated_at'      => 'Actualizado el',
		'updated_at_help' => 'La fecha de actualización.',
		'deleted_at'      => 'Suprimido el',
		'deleted_at_help' => 'La fecha de supresión.',
	]
];