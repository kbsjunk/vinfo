<?php

return [
	'name'       => 'Pays',
	'attributes' => [
	]
];