<?php

return [
	'name'       => 'Devise',
	'attributes' => [
		'code'            => 'Code',
		'code_help'       => 'Entrez le code de la devise.',
		'name'            => 'Nom',
		'name_help'       => 'Entrez le nom de la devise.',
		'created_at'      => 'Crée le',
		'created_at_help' => 'Entrez la date de création.',
		'updated_at'      => 'Mise à jour le',
		'updated_at_help' => 'Entrez la date de mise à jour.',
		'deleted_at'      => 'Supprimé le',
		'deleted_at_help' => 'Entrez la date de suppresion.',
	]
];