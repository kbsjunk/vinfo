<?php

return [

	'attributes' => [
		'id'              => 'Clé',
		'id_help'         => 'La clé de l’enregistrement.',
		'code'            => 'Code',
		'code_help'       => 'Le code de l’enregistrement.',
		'name'            => 'Nom',
		'name_help'       => 'Le nom  de l’enregistrement.',
		'created_at'      => 'Crée le',
		'created_at_help' => 'La date de création de l’enregistrement.',
		'created_by'      => 'Crée pour',
		'created_by_help' => 'Le nom de l’utilisateur qui a creé l’enregistrement.',
		'deleted_at'      => 'Supprimé le',
		'deleted_at_help' => 'La date de suppresion de l’enregistrement.',
		'deleted_by'      => 'Supprimé pour',
		'deleted_by_help' => 'Le nom de l’utilisateur qui a supprimé l’enregistrement.',
		'updated_at'      => 'Mise à jour le',
		'updated_at_help' => 'La date de mise à jour de l’enregistrement.',
		'updated_by'      => 'Mise à jour pour',
		'updated_by_help' => 'Le nom de l’utilisateur qui a mis à jour l’enregistrement.',
	],
];