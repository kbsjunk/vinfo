<?php

return [

	'back'     => 'Back',
	'cancel'   => 'Cancel',
	'delete'   => 'Delete',
	'login'    => 'Login',
	'logout'   => 'Logout',
	'new'      => 'New',
	'ok'       => 'OK',
	'register' => 'Register',
	'save'     => 'Save',
	'search'   => 'Search',

];
