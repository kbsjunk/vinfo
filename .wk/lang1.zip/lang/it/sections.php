<?php

return [

	'account'      => 'Account',
	'settings'     => 'Settings',
	'admin'        => 'Configuration',
	'countries'    => 'Paesi',
	'currencies'   => 'Valute',
	'bottle_sizes' => 'Bottle Sizes',

];
