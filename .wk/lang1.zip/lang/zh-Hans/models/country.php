<?php

return [
	'name'       => '国家',
	'attributes' => [
	]
];