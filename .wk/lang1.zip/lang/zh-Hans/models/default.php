<?php

return [
	'attributes' => [
		'id'              => '關鍵欄位',
		'id_help'         => '记录的關鍵欄位',
		'code'            => '代码',
		'code_help'       => '记录的代码。',
		'name'            => '名字',
		'name_help'       => '记录的名字。',
		'created_at'      => '创建',
		'created_at_help' => '记录创建的日期。',
		'updated_at'      => '更新',
		'updated_at_help' => '记录更新的日期。',
		'deleted_at'      => '删除',
		'deleted_at_help' => '记录删除的日期。',
	]
];