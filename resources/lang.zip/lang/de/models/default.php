<?php

return [

	'attributes' => [
		'id'              => 'ID-Nr.',
		'id_help'         => 'Die ID-Nr. des Datensatzes.',
		'name'            => 'Name',
		'name_help'       => 'Der Name des Datensatzes.',
		'code'            => 'Name',
		'code_help'       => 'Der Code des Datensatzes.',
		'created_at'      => 'Erstellt am',
		'created_at_help' => 'Das Erstellungsdatum des Datensatzes.',
		'created_by'      => 'Erstellt von',
		'created_by_help' => 'Der Name des Benutzers, der den Datensatz erstellt hat.',
		'deleted_at'      => 'Gelöscht am',
		'deleted_at_help' => 'Das Löschungsdatum des Datensatzes.',
		'deleted_by'      => 'Gelöscht von',
		'deleted_by_help' => 'Der Name des Benutzers, der den Datensatz gelöscht hat.',
		'updated_at'      => 'Aktualisert am',
		'updated_at_help' => 'Das Aktualisierungsdatum des Datensatzes.',
		'updated_by'      => 'Aktualisiert von',
		'updated_by_help' => 'Der Name des Benutzers, der den Datensatz aktualisiert hat.',
	],
];