<?php

return [
	'name'       => 'Bottle',
	'attributes' => [
		'id'                      => 'ID',
		'id_help'                 => 'Enter the ID of the bottle.',
		'user_id'                 => 'User',
		'user_id_help'            => 'Enter the user of the bottle.',
		'vintage_id'              => 'Vintage',
		'vintage_id_help'         => 'Enter the vintage of the bottle.',
		'rack_id'                 => 'Rack',
		'rack_id_help'            => 'Enter the rack of the bottle.',
		'shelf_id'                => 'Shelf',
		'shelf_id_help'           => 'Enter the shelf of the bottle.',
		'bottle_size_id'          => 'Bottle Size',
		'bottle_size_id_help'     => 'Enter the bottle size of the bottle.',
		'case_id'                 => 'Case',
		'case_id_help'            => 'Enter the case of the bottle.',
		'case_override'           => 'Case Override',
		'case_override_help'      => 'Enter the case override of the bottle.',
		'vendor_id'               => 'Vendor',
		'vendor_id_help'          => 'Enter the vendor of the bottle.',
		'purchased_at'            => 'Purchased At',
		'purchased_at_help'       => 'Enter the purchased date of the bottle.',
		'consumed_reason_id'      => 'Consumed Reason',
		'consumed_reason_id_help' => 'Enter the consumed reason of the bottle.',
		'consumed_at'             => 'Consumed At',
		'consumed_at_help'        => 'Enter the consumed date of the bottle.',

	]
];