<?php

return [

	'account'      => 'Cuenta',
	'settings'     => 'Ajustes',
	'admin'        => 'Configuración',
	'countries'    => 'Países',
	'currencies'   => 'Monedas',
	'bottle_sizes' => 'Tamaños de botellas',

];
