<?php

return [
	
	'account'      => 'Compte',
	'settings'     => 'Paramètres',
	'admin'        => 'Configuration',
	'countries'    => 'Pays',
	'currencies'   => 'Devises',
	'bottle_sizes' => 'Tailles de bouteilles',
	'users'        => 'Utilisateurs',
	'languages'    => 'Langues',
	'details'    => 'Détails',
	'translations'    => 'Traductions',

];
