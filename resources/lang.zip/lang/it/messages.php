<?php

return [

	'success'       => 'Success',
	'error'         => 'Error',
	
	'saved_success' => 'The record was successfully saved.',
	'saved_error'   => 'There was an error saving the record.',

	'deleted_success' => 'The record was successfully deleted.',
	'deleted_error'   => 'There was an error deleting the record.',

	'yes' => 'Sì',
	'no'  => 'No',

];
