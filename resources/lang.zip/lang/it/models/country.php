<?php

return [
	'name'       => 'Paese',
	'attributes' => [
		'code'            => 'Codice',
		'code_help'       => 'Enter the code of the country.',
		'name'            => 'Nome',
		'name_help'       => 'Enter the name of the country.',
		'created_at'      => 'Creato il',
		'created_at_help' => 'Enter the created date of the country.',
		'updated_at'      => 'Aggiornato il',
		'updated_at_help' => 'Enter the updated date of the country.',
		'deleted_at'      => 'Cancellato il',
		'deleted_at_help' => 'Enter the deleted date of the country.',
	]
];