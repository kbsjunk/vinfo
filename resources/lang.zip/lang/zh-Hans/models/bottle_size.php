<?php

return [
	'name'       => '瓶尺寸',
	'attributes' => [
		'name'            => '名字',
		'name_help'       => '输入名字。',
		'capacity'        => '容量',
		'capacity_help'   => '输入容量。',
		'is_common'       => '常用的？',
		'is_common_help'  => '这个尺寸常用吗？',
		'created_at'      => '创建',
		'created_at_help' => '输入创建日期。',
		'updated_at'      => '更新',
		'updated_at_help' => '输入更新日期。',
		'deleted_at'      => '删除',
		'deleted_at_help' => '输入删除日期。',
	]
];