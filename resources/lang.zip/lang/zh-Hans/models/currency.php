<?php

return [
	'name'       => '货币',
	'attributes' => [
		'code'            => '代码',
		'code_help'       => '输入代码。',
		'name'            => '名字',
		'name_help'       => '输入名字。',
		'created_at'      => '创建',
		'created_at_help' => '输入创建日期。',
		'updated_at'      => '更新',
		'updated_at_help' => '输入更新日期。',
		'deleted_at'      => '删除',
		'deleted_at_help' => '输入删除日期。',
	]
];