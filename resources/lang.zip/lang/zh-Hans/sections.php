<?php

return [

	'account'      => '帐户',
	'settings'     => '设置',
	'admin'        => '组态',
	'countries'    => '国家',
	'currencies'   => '货币',
	'bottle_sizes' => '瓶尺寸',

];
